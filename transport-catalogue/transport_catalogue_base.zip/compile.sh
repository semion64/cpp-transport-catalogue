#!/bin/bash

sudo g++ main.cpp input_reader.cpp stat_reader.cpp transport_catalogue.cpp request_handler.cpp domain.cpp 
